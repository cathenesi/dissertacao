Dependencies:
=============

The dependencies are located in lib/dependencies and must be available on the application classpath.

Maven 2 and 3:
========

If your project is using Maven 2 or 3 you may simply add this dependency to your POM in order to get jade4spring and it's dependencies:
<dependency>
  <groupId>net.sf.jade4spring</groupId>
  <artifactId>jade4spring</artifactId>
  <version>x.x</version>
</dependency>

You will have to add this repository to your setting.xml file, or your project's POM:
http://jade4spring.sourceforge.net/m2repo/
